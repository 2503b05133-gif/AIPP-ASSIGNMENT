def add(a, b):  # Correct - has colon
    return a + b
